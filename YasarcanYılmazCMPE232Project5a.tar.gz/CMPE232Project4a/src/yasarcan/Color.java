package yasarcan;

public enum Color {
	WHITE,
	GRAY,
	BLACK;

}
