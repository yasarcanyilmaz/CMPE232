package yasarcan;

public class GraphExceptions extends Exception {

	public GraphExceptions(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 9056166444200917115L;

}
