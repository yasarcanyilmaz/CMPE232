package yasarcan;

public enum Color {

	WHITE,
	GREY,
	BLACK
	
}
