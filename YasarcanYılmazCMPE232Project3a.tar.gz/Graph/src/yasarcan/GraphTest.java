package yasarcan;

import static org.junit.Assert.*;

import org.junit.Test;

public class GraphTest {

	@Test
	public void testGraph() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsEmpty() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddVertexVertexOfT() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddVertexT() {
		fail("Not yet implemented");
	}

	@Test
	public void testSize() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetRootVertex() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetRootVertex() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetVertex() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetVerticies() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddEdge() {
		fail("Not yet implemented");
	}

	@Test
	public void testInsertBiEdge() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetEdges() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveVertex() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveEdge() {
		fail("Not yet implemented");
	}

	@Test
	public void testClearMark() {
		fail("Not yet implemented");
	}

	@Test
	public void testClearEdges() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindVertexByName() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindVertexByData() {
		fail("Not yet implemented");
	}

	@Test
	public void testRead() {
		fail("Not yet implemented");
	}

	@Test
	public void testReadFromMatrix() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

}
