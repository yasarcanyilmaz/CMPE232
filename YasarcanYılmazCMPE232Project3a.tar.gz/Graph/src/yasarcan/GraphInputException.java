package yasarcan;

public class GraphInputException extends Exception {

	public GraphInputException(String message) {
		super(message);
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 7161588092235760288L;

}
