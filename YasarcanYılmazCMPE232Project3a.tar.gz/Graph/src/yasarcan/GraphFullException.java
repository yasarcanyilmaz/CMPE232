package yasarcan;

public class GraphFullException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2442528722172713070L;

}
