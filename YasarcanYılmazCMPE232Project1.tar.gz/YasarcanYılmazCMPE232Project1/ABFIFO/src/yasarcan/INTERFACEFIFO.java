package yasarcan;

public interface INTERFACEFIFO {
	boolean insert(Object o);
	Object Extract();
	boolean isEmpty();
}
