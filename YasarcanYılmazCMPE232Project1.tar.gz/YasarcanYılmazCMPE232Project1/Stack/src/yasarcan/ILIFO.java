package yasarcan;

public interface ILIFO {

	 boolean insert (Object o);
	 Object extract();
	 boolean isEmpty();
	 
	
}
